import { sayHi } from './helloworld';

sayHi();
