const mongoose = require("mongoose")
const Schema = mongoose.Schema; //ODM ORM

const envModel = new Schema(
    {
        nombre:{
            type: "string",
            unique: true,
            required: true
        },
        usuario:{
            type:"string",
            required: true
        },
        password:{
            type:"string",
            required: true
        },
        correo:{
            type:"string",
            required: true
        }
    }
)

module.exports = mongoose.model("Usuarios",envModel)