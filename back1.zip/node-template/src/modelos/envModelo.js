const mongoose = require("mongoose")
const Schema = mongoose.Schema;

const envSchema = new Schema(
    { 
    dirR:{
        type: "string",
        unique: true,
        required: true
    },
    cityR:{
        type:"string",
        required: true
    },
    name:{
        type:"string",
        required: true
    },
    cedula:{
        type:"number",
        required: true
    },
    dirE:{
        type:"string",
        required: true
    },
    cityE:{
        type:"string",
        required: true
    }
});

module.exports = mongoose.model("envios",envSchema)