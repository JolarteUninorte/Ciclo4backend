"use strict";
//Importa la libreria express
const express = require("express");
//Parsear el contenido a JSON
const bodyParser = require("body-parser");
const cors = require("cors");
// Importa la libreria de mongoose
const mongoose = require("mongoose");
const crypto = require('crypto');

// Instancia el framework express
const app = express();
//Parsea los datos a json
app.use(bodyParser.json());

//Middleware
app.use(cors())
const userp = require("./src/modelos/prodModelo");
const User1 = require("./src/modelos/prodModelo");
const envio = require("./src/modelos/envModelo");

app.post("/login", (req, res) => {
    const { usu, pass } = req.body //{ usu: "admin", pass:"1234" }
    //const passCifrado = crypto.createHash('sha256').update(pass).digest('hex');
    User1.findOne({ usuario: usu, password: pass }, (error, dataUsu) => {
        if (error) {
            return res.send({ msg: "usuario o contraseña incorrecta", estado: "error" })
        } else {
            if (dataUsu !== null) {
                return res.send({ estado: "ok", url: ".../Estado" })
            }
        }
        return res.send({ msg: "usuario o contraseña incorrecta", estado: "error" })
    })
})

app.post("/user/save", (req, res) => {
    const data = req.body
    const user = new userp(data);
    user.save((error) => {
        if (error) {
            return res.send({ msg: "Error al guardar", estado: "error" })
        }
        return res.send({ msg: "Guardado con éxito", estado: "ok",url: ".../Estado" })
    });
})

app.post("/user/envios", (req, res) => {
    const data = req.body
    const env = new envio(data);
    env.save((error) => {
        if (error) {
            return res.send({ msg: "Error al guardar", estado: "error" })
        }
        return res.send({ msg: "Guardado con éxito", estado: "ok",url: "/Envios" })
    });
})


//Se conecta a BD mongodb
//mongoose.connect("mongodb+srv://rperez:facil123456@cluster0.3nhnv.mongodb.net/tienda?retryWrites=true&w=majority")
mongoose.connect("mongodb+srv://jcpb1:jcpb0221@cluster0.jka5gkw.mongodb.net/Cluster0?retryWrites=true&w=majority")
    .then(res => console.log("Conectado a BD"))
    .catch(err => console.log(err))

app.listen(8000, () => {
    console.log(`Server is running on port 8000.`);
});